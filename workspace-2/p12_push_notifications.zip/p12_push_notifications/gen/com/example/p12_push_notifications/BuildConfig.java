/** Automatically generated file. DO NOT MODIFY */
package com.example.p12_push_notifications;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}